package com.quickfix.homeauto;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
public class MainActivity extends Activity {
 WebView view;
 @Override public void onCreate(Bundle state) { super.onCreate(state); view=new WebView(this); setContentView(view); view.setFitsSystemWindows(true); view.getSettings().setJavaScriptEnabled(true); view.getSettings().setDomStorageEnabled(true); view.setWebViewClient(new WebViewClient(){ @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){ return open(r.getUrl()); } @Override public boolean shouldOverrideUrlLoading(WebView v,String url){ return open(Uri.parse(url)); }}); view.loadUrl("file:///android_asset/index.html"); }
 boolean open(Uri uri){ if("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) { try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch(Exception e){ Toast.makeText(this,"No browser available",Toast.LENGTH_SHORT).show(); } return true; } return !"file".equals(uri.getScheme()); }
 @Override public void onBackPressed(){ if(view.canGoBack()) view.goBack(); else super.onBackPressed(); }
}
